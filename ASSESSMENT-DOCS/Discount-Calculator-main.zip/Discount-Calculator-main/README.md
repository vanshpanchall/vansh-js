# Discount-Calculator with JavaScript
