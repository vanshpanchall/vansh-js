let promoInput = document.getElementById('promoInput');
let amount = document.getElementById('amount');
let check = document.getElementById('check');
let getAmount = document.getElementById('getAmount');
let total = document.getElementById('total');
let total1 = document.getElementById('total1');


amount.addEventListener('blur', function () {
    let price = Number(amount.value);
    getAmount.innerHTML = amount.value;
    total.innerHTML = price + (price * 18) / 100;
});

check.addEventListener('click', function () {
    if (amount.value !== 0 && promoInput.value.trim() != 0) {
        getAmount.innerHTML = amount.value;
    }
    calculateDiscount();
});

promoInput.addEventListener('focus', function () {
    check.disabled = true
});




function calculateDiscount() {
    let promo = ["off25%", "off50%", "off75%"];
    let discount = promoInput.value.toLowerCase().split(" ").filter(Boolean).join("");
    let priceAfterGST = (Number(amount.value) + (amount.value * 18) / 100);
    if (amount.value >= 500 && amount.value < 2000) {
        if (discount == 'off25%') {
            total.innerHTML = `(-25%)${priceAfterGST - (priceAfterGST * 25) / 100}`;
            total1.innerHTML = priceAfterGST - (priceAfterGST * 25) / 100;
        }
    } else if (amount.value >= 2000 && amount.value <= 4000) {
        if (discount == 'off25%') {
            total.innerHTML = `(-25%)${priceAfterGST - (priceAfterGST * 25) / 100}`;
            total1.innerHTML = priceAfterGST - (priceAfterGST * 25) / 100;
        } else if (discount == 'off50%') {
            total.innerHTML = `(-50%)${priceAfterGST - (priceAfterGST * 50) / 100}`;
            total1.innerHTML = priceAfterGST - (priceAfterGST * 25) / 100;
        }
    } else if (amount.value > 4000) {
        if (discount == 'off25%') {
            total.innerHTML = `(-25%)${priceAfterGST - (priceAfterGST * 25) / 100}`;
            total1.innerHTML = priceAfterGST - (priceAfterGST * 25) / 100;
        } else if (discount == 'off50%') {
            total.innerHTML = `(-50%)${priceAfterGST - (priceAfterGST * 50) / 100}`;
            total1.innerHTML = priceAfterGST - (priceAfterGST * 25) / 100;
        } else if (discount == 'off75%') {
            total.innerHTML = `(-75%)${priceAfterGST - (priceAfterGST * 75) / 100}`;
            total1.innerHTML = priceAfterGST - (priceAfterGST * 25) / 100;
        }
    }

}