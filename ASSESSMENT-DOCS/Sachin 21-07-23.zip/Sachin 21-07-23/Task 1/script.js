let emailInput = document.getElementById('email')
let passInput = document.getElementById('pass')

let btn = document.getElementById('btn')
btn.addEventListener('click', () => {
    alert("You entered: " + emailInput.value + "\n" + "Your password: " + passInput.value)
})