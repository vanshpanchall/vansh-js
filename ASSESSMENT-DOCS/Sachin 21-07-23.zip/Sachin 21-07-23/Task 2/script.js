let passInput = document.getElementById('pass')
let btn = document.getElementById('btn')
console.log(passInput);
console.log(btn);
btn.addEventListener('click', () => {
    passInput.value = Math.random()*100
    console.log(passInput.value)
})
let click = document.getElementById('click')
click.addEventListener('click', () => {
    alert(passInput.value)
})