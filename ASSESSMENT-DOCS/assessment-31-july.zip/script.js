const initial_amount = document.querySelector('#initial_amount')
const promo_code = document.querySelector('#promo_code')
const check_btn = document.querySelector('.check_btn')
const finalPrice = document.querySelector('#total_amount')
const summaary_prc = document.querySelector('#summary')
const gst = document.querySelector('#gst')
const total_item_prc = document.querySelector('#total_item_prc')
const promo_validation = document.querySelector('#is_promo_valid')
const payment_details = document.querySelector('.payment_details')

const promos = ['OFF25' , 'OFF50' , 'OFF75']
// check_btn.disabled = true;

// if (!initial_amount) {
//     check_btn.disabled = false;
// }

check_btn.addEventListener('click', () =>{
    let new_promo = promo_code.value.toUpperCase();

    summaary_prc.innerText = initial_amount.value
    gst.innerText = 18*initial_amount.value/100
    let withGST = +initial_amount.value + (18*initial_amount.value/100)
    total_item_prc.innerText = withGST

    if (promos.includes(new_promo)) {
        promo_validation.innerText = 'Promo Code applied successfully'
        promo_validation.style.color = 'green'
        promo_validation.style.fontWeight = 'bold'

    }else{
        promo_validation.innerText = 'Invalid Promo Code'
        promo_validation.style.color = 'red'
        promo_validation.style.fontWeight = 'bold'
    }

    if (initial_amount.value>2000) {
        withGST - (+initial_amount.value + (75*initial_amount.value/100))
        console.log(withGST);
        finalPrice.innerText = Math.round(withGST)
    }else if(initial_amount.value >1000){
        withGST - (+initial_amount.value + (75*initial_amount.value/100))
        console.log(withGST);
        finalPrice.innerText = Math.round(withGST)
    }else if (initial_amount.value > 500) {
        withGST - (+initial_amount.value + (75*initial_amount.value/100))
        console.log(withGST);
        finalPrice.innerText = Math.round(withGST)
    }
})

function couponCounter(new_promo) {
    switch (new_promo) {
        case 'OFF25' : 
    }
}