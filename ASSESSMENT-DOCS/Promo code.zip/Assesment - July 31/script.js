let myamount = document.getElementById('amount');
const promos = ['OFF25', 'OFF50', 'OFF75'];
let promoinput = document.getElementsByClassName('promoinput')[0];
let checkbtn = document.querySelector('.checkpromo');
let promomessage = document.querySelector('.promomessage');
// let amountmessage = document.querySelector('.amountmessage');
let summaryAmount = document.getElementById('summaryamount');
let totalAmount = document.getElementById('totalamount');
let totalPay = document.getElementById('totalpay');

myamount.addEventListener('change', () => {
    if (Number(myamount.value)) {
        var amountAfterGst = Number(myamount.value) + (Number(myamount.value) * 18 / 100);
        summaryAmount.innerText = 'Rs.' + amountAfterGst;
        totalAmount.innerText = 'Rs.' + amountAfterGst;
        totalPay.innerText = 'Rs.' + amountAfterGst;
    }
    // else{
     
    // }
})

promoinput.addEventListener('change', () => {
    checkbtn.removeAttribute('disabled');
})

checkbtn.addEventListener('click', () => {
    let promocode = promoinput.value.slice(0, 4).toUpperCase() + promoinput.value.slice(4);
    let discountdiv = document.querySelector('.discount');
    if (promos.includes(promocode)) {
        if (Number(myamount.value) > 500 && Number(myamount.value) < 1000) {
            if (promocode == 'OFF25') {
                promomessage.innerText = promocode + ' Applied';
                promomessage.style.color = 'green';
                off25();
            }
            else {
                promomessage.innerText = promocode + " Not Applicable";
                promomessage.style.color = 'orange';
            }
        }
        else if (Number(myamount.value) > 1000 && Number(myamount.value) < 2000) {
            if (promocode == 'OFF25' || promocode == 'OFF50') {
                promomessage.innerText = promocode + ' Applied';
                promomessage.style.color = 'green';
                if (promocode == 'OFF25') {
                    off25();
                }
                else if (promocode == 'OFF50') {
                    off50();
                }
            }
            else {
                promomessage.innerText = promocode + " Not Applicable";
                promomessage.style.color = 'orange';
            }
        }
        else if (Number(myamount.value) > 2000) {
            if (promocode == 'OFF25' || promocode == 'OFF50' || promocode == 'OFF75') {

                promomessage.innerText = promocode + ' Applied';
                promomessage.style.color = 'green';
                if (promocode == 'OFF25') {
                    off25();
                }
                else if (promocode == 'OFF50') {
                    off50();
                }
                else if (promocode == 'OFF75') {
                    off75();
                }
            }
        }
        else {
            promomessage.innerText = promocode + " Not Applicable";
            promomessage.style.color = 'orange';
        }
        discountdiv.style.display = 'flex';
        discountdiv.style.justifyContain = 'space-between';
    }
    else {
        promomessage.innerText = "Invalid promocode";
        promomessage.style.color = 'red';
    }
})
let discountedprice = document.getElementById('discountprice');
function off25() {
    var amountAfterGst = Number(myamount.value) + (Number(myamount.value) * 18 / 100);
    let amountAfter25 = amountAfterGst - amountAfterGst * 25 / 100;
    let discount25 = amountAfterGst * 25 / 100
    summaryAmount.innerText = 'Rs.' + amountAfterGst;
    discountedprice.innerText = 'Rs.' + discount25;
    totalAmount.innerText = 'Rs.' + amountAfter25;
    totalPay.innerText = 'Rs.' + amountAfter25;
}
function off50() {
    var amountAfterGst = Number(myamount.value) + (Number(myamount.value) * 18 / 100);
    let amountAfter50 = amountAfterGst - amountAfterGst * 50 / 100;
    let discount50 = amountAfterGst * 50 / 100
    summaryAmount.innerText = 'Rs.' + amountAfterGst;
    discountedprice.innerText = 'Rs.' + discount50;
    totalAmount.innerText = 'Rs.' + amountAfter50;
    totalPay.innerText = 'Rs.' + amountAfter50;

}
function off75() {
    var amountAfterGst = Number(myamount.value) + (Number(myamount.value) * 18 / 100);
    let amountAfter75 = amountAfterGst - amountAfterGst * 75 / 100;
    let discount75 = amountAfterGst * 75 / 100
    summaryAmount.innerText = 'Rs.' + amountAfterGst;
    discountedprice.innerText = 'Rs.' + discount75;
    totalAmount.innerText = 'Rs.' + amountAfter75;
    totalPay.innerText = 'Rs.' + amountAfter75;
}