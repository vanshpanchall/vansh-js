let code = document.querySelector("#code");
let check = document.querySelector(".check");
let newAmt = document.querySelectorAll(".amt");
let getAMt = document.querySelector("#enterAmt");
let error=document.querySelector(".invalid")

check.addEventListener("click", (e) => {

  if (code.value == "OFF25") {
      newAmt.textContent = getAMt.value - (getAMt.value * 25) / 100;
      error.textContent="OFF25 Applied!"
  }
  else if (code.value == "OFF50") {
      newAmt.textContent = getAMt.value - (getAMt.value * 50) / 100;
      error.textContent = "OFF50 Applied!";
  }
  else if (code.value == "OFF75") {
      newAmt.textContent = getAMt.value - (getAMt.value * 75) / 100;
      error.textContent = "OFF75 Applied!";
    }
  else {
      error.textContent="Invalid Code"
      error.style.color = 'red';
    }
});
